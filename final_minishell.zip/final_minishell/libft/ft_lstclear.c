/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstclear.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kwillian <kwillian@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/23 15:09:09 by thguimar          #+#    #+#             */
/*   Updated: 2025/07/01 00:45:30 by kwillian         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

// void	ft_lstclear(t_list **lst, void (*del)(void*))
// {
// 	t_list	*ptr;

// 	if (lst)
// 	{
// 		while (*lst)
// 		{
// 			ptr = (*lst)->next;
// 			ft_lstdelone(*lst, del);
// 			*lst = ptr;
// 		}
// 	}
// }
